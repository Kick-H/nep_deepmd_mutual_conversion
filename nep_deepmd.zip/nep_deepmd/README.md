

# deep2nep:
>> python deep2nep.py deepmd

# nep2dep:
>> python nep2xyz.py nep

# Refs:
https://github.com/deepmodeling/dpdata
http://dplibrary.deepmd.net/#/project_details?project_id=202010.002
